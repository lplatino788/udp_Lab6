package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import cliente.FileEvent;


public class ComunicacionUDP extends Thread
{
	//private static FileEvent fileEvent = null;	
	private ArrayList<SecuenciaServidor> secuencia;
	private static int puerto;
	private DatagramSocket socketServidor;
	
	private int objetosRecibidos;	
	private int objetosPerdidos;
	private int objetosTotales;
	
	public ComunicacionUDP(ArrayList<SecuenciaServidor> arreglo)
	{
		super();
		secuencia=arreglo;
	}
	
	public void run() {
		
		
		try {
			this.startUDPServer();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void startUDPServer() throws IOException { 
		

		socketServidor = new DatagramSocket(1008);
		byte[] receiveData = new byte[1024];
		byte[] sendData = new byte[1024];
		
		while(true)
		{
			System.out.println("UDP-Servidor Esperando Clientes");
			DatagramPacket paquete = new DatagramPacket(receiveData,receiveData.length);
			socketServidor.receive(paquete);
			System.out.println("UDP-Paquete recibido");
			
			String mensaje = new String(paquete.getData());
			String[] resp = mensaje.split(":");
			
			InetAddress ip = resp[0];
			int puerto = paquete.getPort();		

			try
			{
				synchronized(secuencia)
				{
					DateFormat format = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss", Locale.ENGLISH);
					Date registro= format.parse(resp[2]);
					System.out.println(registro); // Sat Jan 02 00:00:00 GMT 2010
					secuencia.add(new Secuencia(resp[0], Integer.parseInt(resp[1]), registro));
					//Cambiar número de puerto via linea de comando
					String input = System.console().readLine();
					 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					 System.out.print("Cambiar puerto:");
				     try{
				         int i = Integer.parseInt(br.readLine());
				         puerto=i;
				     }catch(NumberFormatException nfe){
				          System.err.println("Formato inválido");
				     }
				}
			}
			catch(Exception e)
			{
				//Confirmacion Mensaje Perdido
				System.out.println("Un mensaje perdido");
				// Permite conocer el número de objetos perdidos
				objetosPerdidos++;
			}

			System.out.println("UDP-Recibido: IP= "+ip+" Numero Secuencia= "+resp[0]+" marcaTiempo= "+resp[1]+ " Fecha= "+resp[2]);
			// Permite conocer el número de objetos recibidos
			objetosRecibidos++;

			sendData = "OK".getBytes();
			
			DatagramPacket aEnviar = new DatagramPacket(sendData, sendData.length, ip, puerto);
			
			socketServidor.send(aEnviar);
			objetosTotales=objetosRecibidos+objetosPerdidos;
			System.out.println("UDP-Respuesta enviada");	
			System.out.println("Objetos Recibidos: "+ objetosRecibidos+ " Objetos Perdidos: "+ objetosPerdidos+ " Objetos Totales: "+objetosTotales);	
			
		}		
	}
}